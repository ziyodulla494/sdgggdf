import React,{useState,useEffect } from 'react'
// import {Link } from 'react-router-dom'
import Axios from 'axios'
import './Login.css';
export default function LogIn() {
  const[userCheck, setUserCheck]= useState('')
  const[paswordCheck, setPaswordCheck]= useState('')
  const[data,setDate]=useState([])
  const[javob,setJavob]=useState("1")
  const[javob1,setJavob1]=useState("2")
  const[javob2,setJavob2]=useState("3")
  const[javob3,setJavob3]=useState("4")
  useEffect(()=>{
    Axios.get('https://62c52eca134fa108c24a2367.mockapi.io/testuchunregistratsiya/testuchunregistratsiya')
    .then(res=>{
     // malumot.push(res.data)
    
      console.log("Getting from ::::",res.data)
      setDate(res.data)
    }).catch(err => console.log(err)) 
  },[])
 
  const Check = (e)=>{
    for (let i = 0; i < e.length; i++) {
      const element = e[i];
       if (element.user === userCheck) {
          setJavob("usertogri")
        if (element.passvord === paswordCheck) {
          setJavob1("passwordtogri")
          alert("passwordtogri")
        }else{
             setJavob2("kengi pejga otish")
        }
       }else{
        if (javob === "1") {
         
          setJavob3("xato")
        }
       
      }
    }
   
  
     
  }

  return (
//     <div>

// <form>
//     <h1>{javob}</h1>
//     <h1>{javob1}</h1>
//     <h1>{javob2}</h1>
//     <h1>{javob3}</h1>
//       <div class="input-box">
//         <input type="text"  placeholder="Enter your name"  required  value={userCheck} onChange={(e)=>setUserCheck(e.target.value)}  />
//        {console.log(userCheck)}
//       </div>
//       <div class="input-box">
//         <input type="password" placeholder="Confirm password"  required  value={paswordCheck} onChange={(e)=>setPaswordCheck(e.target.value)}  />
//         {console.log(paswordCheck)}
        
//       </div>
//     <div class="input-box button">
//         <input onClick={e=>{ 
// Check(data)}} type="Submit" value="kirish" />
//       </div>
//       </form> 
//     </div>

<div class="container">
<div class="screen">
  <div class="screen__content">
    <form class="login">
      <div class="login__field">
        <i class="login__icon fas fa-user"></i>
        <input type="text" class="login__input" placeholder="User name / Email" value={userCheck} onChange={(e)=>setUserCheck(e.target.value)}/>
      </div>
      <div class="login__field">
        <i class="login__icon fas fa-lock"></i>
        <input type="password" class="login__input" placeholder="Password" onChange={(e)=>setPaswordCheck(e.target.value)}/>
      </div>
      <button class="button login__submit"
        onClick={e=>{ 
         Check(data)
         }} 
         type="Submit" value="kirish">
        <span class="button__text">Log In Now</span>
        <i class="button__icon fas fa-chevron-right"></i>
      </button>        
    </form>
    <div class="social-login">
      <h3>log in via</h3>
      <div class="social-icons">
        <a href="#" class="social-login__icon fab fa-instagram"></a>
        <a href="#" class="social-login__icon fab fa-facebook"></a>
        <a href="#" class="social-login__icon fab fa-twitter"></a>
      </div>
    </div>
  </div>
  <div class="screen__background">
    <span class="screen__background__shape screen__background__shape4"></span>
    <span class="screen__background__shape screen__background__shape3"></span>    
    <span class="screen__background__shape screen__background__shape2"></span>
    <span class="screen__background__shape screen__background__shape1"></span>
  </div>    
</div>
</div>

  )
}

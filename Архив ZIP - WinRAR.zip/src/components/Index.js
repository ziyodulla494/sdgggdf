import React,{useEffect} from 'react';
import Axios from 'axios';
function Index({id, initialName, initialCreatedAt}){
    const [name, setName] = React.useState(initialName)
    const [createdAt, setCreatedAt] = React.useState(initialCreatedAt)

    const postData = (e)=>{
        e.preventDefault();
        Axios.put(`https://6295c5bd75c34f1f3b20d598.mockapi.io/User/${id}`, {name, createdAt})
        .then(res=>console.log('Deleting!!!',res)).catch(err => console.log(err))
    }
    useEffect(()=>{
        setName(localStorage.getItem('name'));
        setCreatedAt(localStorage.getItem('createdAt'));
    },[])
    return (<div>
           <form>
        <label>name</label>
        <input type="text" value={name} onChange={(e)=>setName(e.target.value)}/>
        <hr/>
        <label>age</label>
        <input type="number" value={createdAt} onChange={(e)=>setCreatedAt(e.target.value)}/>
        <hr/>
<button onClick={postData}>Post</button>

      </form>
    </div>);
}
export default Index
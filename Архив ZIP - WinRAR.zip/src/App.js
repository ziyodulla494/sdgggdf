
import React from "react";
import Main from "./Main";
import Main2 from './Main2';
import M from './M';
import {BrowserRouter as Router,Route,Routes } from"react-router-dom"
function App() {
  
  return (
    <div className="App">
     <Router>
       <Routes>
         <Route path="/" exact element={<Main/>}/>
         <Route path="/main/:id"  element={<Main2/>}/>
         <Route path="m"  element={<M/>}/>
       </Routes>
       </Router> 
      

    </div>
  );
}

export default App;

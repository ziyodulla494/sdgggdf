
import  Axios  from 'axios';
import './sihnup.css'
// import { Button } from 'react-bootstrap';
import React,{ useEffect, useState } from 'react';
// import{useNavigate} from "react-router-dom"
// import Main2 from './Main2';
function SignUp() {
  const[data,setDate]=useState([])
  const [user,setUser]=useState('')
  // const [editId,setEditId]=useState()
  const [email,setEmail]=useState('')
  const [surName, setSurName] =useState('')
  const [age, setAge] =useState('')

  const [tele, setTele] = useState('')
  const [passvord, setPassvord] = useState()
  

// const navigate=useNavigate()
// const onClick=(id)=>{
// setTimeout(() => {
//     navigate("main")
// }, 100);
// }
  useEffect(()=>{
    Axios.get('https://62c52eca134fa108c24a2367.mockapi.io/testuchunregistratsiya/testuchunregistratsiya')
    .then(res=>{
      console.log("Getting from ::::",res.data)
      setDate(res.data)
    }).catch(err => console.log(err)) 
  },[])

  const postData=(e)=>{
    if (user===" "||surName===""||age===""||email===""||passvord===undefined||tele==="") {
      
      alert("qatorlarda biri to'liq emas ")
    }else{
    //   setUser(''),
    //   setSurName(''),
    //  setEmail(''),
    //  setAge(''),
    //  setTele(''),
    //  setPassvord(''),
      e.preventDefault();
      Axios.post('https://62c52eca134fa108c24a2367.mockapi.io/testuchunregistratsiya/testuchunregistratsiya',{
        user,
        surName,
        age,
        email,
        tele,
        passvord
        

      }).then(res=>console.log('Posting data',res)).catch(err => console.log(err))
      alert(" qabul qilndi")
    }

  }
//   const postDelete=(id,e)=>{
//     e.preventDefault();
//     Axios.delete(https://62c52eca134fa108c24a2367.mockapi.io/testuchunregistratsiya/testuchunregistratsiya/${id})
//     .then(res=>console.log('Deleting!!!',res)).catch(err => console.log(err))
//   }
  
  // const arr =data.map((data,index)=>{
  //   return(
  //     <tr>
  //       <td style={{border:"1px solid black"}}>{data.id}</td>
  //       <td style={{border:"1px solid black"}}>{data.user}</td>
  //       <td style={{border:"1px solid black"}}>{data.surName}</td>
  //       <td style={{border:"1px solid black"}}>{data.age}</td>
  //       <td style={{border:"1px solid black"}}>{data.email}</td>
  //       <td style={{border:"1px solid black"}}>{data.tele}</td>
  //       <td style={{border:"1px solid black"}}>{data.passvord}</td>
        
  //       <td style={{border:"1px solid black"}}><button onClick={()=>{
  //           //setEditId(data.id);
  //            onClick(data.id);
  //            }}>update</button></td>
  //       <td style={{border:"1px solid black"}}><button onClick={(e)=>postDelete(data.id,e)}>delete</button></td>
  //     </tr>
  //   )
  // })
  return (
    <div className="App">
      
     
        
      {/* <label>name</label>
        <input required  type="text"  value={user} onChange={(e)=>setUser(e.target.value)}/>
        <hr/>
        <label>surname</label>
        <input required type="text" value={surName} onChange={(e)=>setSurName(e.target.value)}/>
        <hr/>
        <label>age</label>
        <input required type="number" value={age} onChange={(e)=>setAge(e.target.value)}/>
        <hr/>
        <label>email</label>
        <input required type="email" value={email} onChange={(e)=>setEmail(e.target.value)}/>
        <hr/>
        <label>tel</label>
        <input required type="number" value={tele} onChange={(e)=>setTele(e.target.value)}/>
        <hr/>
        <label>emaildf</label>
        <input required type="password" value={passvord} onChange={(e)=>setPassvord(e.target.value)}/>
        {console.log(passvord)}
        <hr/>
        <button type='submit' onClick={postData} >Add</button> */}
   {/* <Button>33</Button> */}
    
<div className="login-page">
  {/* <div className="form">
    <form className="register-form">
         <label>name</label><br/>
        <input required  type="text"  value={user} onChange={(e)=>setUser(e.target.value)}/><br/>
      
        <label>surname</label><br/>
        <input required type="text" value={surName} onChange={(e)=>setSurName(e.target.value)}/><br/>
      
        <label>age</label><br/>
        <input required type="number" value={age} onChange={(e)=>setAge(e.target.value)}/><br/>
      
        <label>email</label><br/>
        <input required type="email" value={email} onChange={(e)=>setEmail(e.target.value)}/><br/>
      
        <label>tel</label><br/>
        <input required type="number" value={tele} onChange={(e)=>setTele(e.target.value)}/><br/>
      
        <label>password</label>
        <input required type="password" value={passvord} onChange={(e)=>setPassvord(e.target.value)}/>
        <br/>        
      
        <button className="zz" type='submit' onClick={postData} ></button>
    </form>
  </div> */}
   {/* axa */}
  <div class="wrapper" > 
    <h2>Registration</h2>
    <form 
    >
      <div class="input-box">
        <input type="text" placeholder="Enter your name" required  value={user} onChange={(e)=>setUser(e.target.value)}/>
      </div>
      <div class="input-box">
        <input type="text" placeholder="Enter your surName" required value={surName} onChange={(e)=>setSurName(e.target.value)} />
      </div>
      <div class="input-box">
        <input  type="number" placeholder="Enter your age" value={age} onChange={(e)=>setAge(e.target.value)} />
      </div>
      <div class="input-box">
        <input type="email" placeholder="Enter your email" required  value={email} onChange={(e)=>setEmail(e.target.value)} />
      </div>
      <div class="input-box">
        <input type="number" placeholder="Enter your tele" required value={tele} onChange={(e)=>setTele(e.target.value)} />
      </div>
      <div class="input-box">
        <input type="password" placeholder="Confirm password" required  value={passvord} onChange={(e)=>setPassvord(e.target.value)} />
      </div>
      <div class="input-box button">
        <input type="Submit" value="Add" onClick={postData}/>
      </div>
      <div class="text">
        {/* <h3>Already have an account? <a href="#">Login now</a></h3> */}
      </div>
    </form>
  </div>

</div>

{/* <table style={{border:'1px solid black'}}>
  <tr>
    <th style={{border:'1px solid black'}}>ID</th>
    <th style={{border:'1px solid black'}}>name</th>
    <th style={{border:'1px solid black'}}>surname</th>
    <th style={{border:'1px solid black'}}>age</th>
    <th style={{border:'1px solid black'}}>email</th>
    <th style={{border:'1px solid black'}}>tel</th>
    <th style={{border:'1px solid black'}}>passvord</th>
    <th style={{border:'1px solid black'}}>update</th>
    <th style={{border:'1px solid black'}}>delete</th>
  </tr>
  {arr}
</table> */}
{/* {!! editId && <Main2 name={editId} key={editId


} initialName={data.user} initialAge={data.age} initialEmail={data.email} 
initialSurNAme={data.surName} initialTele={data.tele} initialPassvord={data.passvord}/>} */}

    </div>
  );
}

export default SignUp;
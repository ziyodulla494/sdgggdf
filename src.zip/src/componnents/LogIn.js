import React,{useState,useEffect } from 'react'
import {Link } from 'react-router-dom'
import Axios from 'axios'

export default function LogIn() {
  const[userCheck, setUserCheck]= useState('')
  const[paswordCheck, setPaswordCheck]= useState('')
  const[data,setDate]=useState([])
  const malumot=[]
  const[javob,setJavob]=useState("wd")
  const[javob1,setJavob1]=useState("wd")
  useEffect(()=>{
    Axios.get('https://62c52eca134fa108c24a2367.mockapi.io/testuchunregistratsiya/testuchunregistratsiya')
    .then(res=>{
     // malumot.push(res.data)
    
      console.log("Getting from ::::",res.data)
      setDate(res.data)
    }).catch(err => console.log(err)) 
  },[])
 
  const Check = (e)=>{
    
     e.forEach(test=>{
      if (test.user === userCheck) {
         alert("user togri")
        if (test.passvord === paswordCheck) {
          alert("password togri")
        }else{
          alert("password xato")
          }
        } else{
          
            alert("xato")
      
        }                                                                              
      })
     
  
  }

  return (
    <div>

<form>
    <h1>{javob}</h1>
    <h1>{javob1}</h1>
      <div class="input-box">
        <input type="text"  placeholder="Enter your name"  required  value={userCheck} onChange={(e)=>setUserCheck(e.target.value)}  />
       {console.log(userCheck)}
      </div>
      <div class="input-box">
        <input type="password" placeholder="Confirm password"  required  value={paswordCheck} onChange={(e)=>setPaswordCheck(e.target.value)}  />
        {console.log(paswordCheck)}
        
      </div>
    <div class="input-box button">
        <input onClick={e=>{ Check(data)  }} type="Submit" value="kirish" />
      </div>
      </form> 
    </div>
  )
}

import React, { Component } from 'react';
import './nav.css'
import{Link} from'react-router-dom'
class Nav extends Component{
  render(){
    return(
      <div>
      <nav className='NavbarItems'>
         <h1 className='navbar-logo'>
          react
         </h1>
         <div className='menu-icon'>
          <ul>
        <Link to='/'> <li className='li'>Home</li></Link>   
           
           <Link to="/contact" ><li className='li'>Contact</li></Link>
           <Link to="/login" > <li className='li'>Login</li></Link>
           <Link to="/signup" ><li className='li'>Sign up</li></Link>
          </ul>
         </div>
      </nav>
      </div>
    )
  }
}
export default Nav
// import React from 'react';
// import './nav.css'
// import{Link} from'react-router-dom'
// export default function Nav() {
//     return(
//       <div>
//       <nav className='NavbarItems'>
//          <h1 className='navbar-logo'>
//           react
//          </h1>
//          <div className='menu-icon'>
//           <ul>
//         <Link to='/'> <li className='li'>Home</li></Link>   

//            <Link to="/contact" ><li className='li'>Contact</li></Link>
//            <Link to="/login" > <li className='li'>Login</li></Link>
//            <Link to="/signup" ><li className='li'>Sign up</li></Link>
//           </ul>
//          </div>
//       </nav>
//       </div>
//     )

// }


import React from 'react'
import './nav.css'
export default function Nav() {
  return (
    <div className='hero'>
      <nav>
        <h2 className='logo' >Onlayn <span className='test'>test</span></h2>
      <ul>
        <li><a href='#' >hom</a></li>
        <li><a href='#' >hom</a></li>
        <li><a href='#' >hom</a></li>
        <li><a href='#' >hom</a></li>
        <li><a href='#' >hom</a></li>
      </ul>
      <button type='button'>Say up</button>
      </nav>
      
    </div>
  )
}

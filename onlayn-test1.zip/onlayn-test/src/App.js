import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Main from './login/Main';
import 'bootstrap/dist/css/bootstrap.min.css';
import Mailer from './login/Mailer';

class App extends Component {
  render() {
    
    return (
    
       <Main/>
      // <Mailer/>
  
     
    
    );
  }
}

export default App;
